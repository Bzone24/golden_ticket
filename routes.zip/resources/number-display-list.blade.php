<div class="card mb-3 h-100">

    <!-- Timer Header -->
    @include('livewire.ticket-data-form')

    <div class="card-header text-black">
        <div class="d-flex justify-content-between align-items-center px-2 py-1 border-bottom w-100">
            @php
                use Illuminate\Support\Str;

                // Decide time format based on presence of seconds
                $formatFromString = function ($s) {
                    return is_string($s) && substr_count($s, ':') >= 2 ? 'g:i:s A' : 'g:i A';
                };

                $addOneMinute = function ($t) use ($formatFromString) {
                    try {
                        $dt = \Illuminate\Support\Carbon::parse($t)->addMinute();
                        $fmt = $formatFromString((string) $t);
                        return $dt->format($fmt);
                    } catch (\Throwable $e) {
                        return $t;
                    }
                };

                if (!empty($selected_times)) {
                    $selected_times_arr = is_array($selected_times) ? $selected_times : [$selected_times];
                    $times = array_map($addOneMinute, $selected_times_arr);
                } elseif (isset($active_draw)) {
                    $raw = $active_draw->formatEndTime();
                    $times = [$addOneMinute($raw)];
                } else {
                    $times = [];
                }

                $labels = !empty($selected_game_labels)
                    ? $selected_game_labels
                    : collect($games ?? [])
                        ->whereIn('id', $selected_games ?? [])
                        ->map(fn($g) => strtoupper($g->code ?? ($g->short_code ?? ($g->name ?? ''))))
                        ->values()
                        ->all();
            @endphp

            <h6 class="mb-0 w-100 text-center">
                @foreach ($this->selectedDraws as $key => $draw)
                    <strong>Draw:</strong> {{ $draw->formatResultTime() }} ,
                    <strong></strong>{{ $draw->draw->game->name }} |
                @endforeach
            </h6>
        </div>
    </div>

    <div class="card-body pb-0 py-0">
        {{-- Simple ABC Section --}}
        <div class="mb-0">
            <h5 class="fw-semibold">Simple ABC</h5>

            <!-- Fixed height + scroll only inside table area -->
            <div id="printSimpleArea" style="max-height: 300px; overflow-y: auto;">
                <table class="table table-bordered table-striped table-hover mb-0 text-center fw-bold">
                    <thead class="table-light position-sticky top-0" style="z-index: 1;">
                        <tr>
                            {{-- <th>#</th> --}}
                            <th>Option</th>
                            <th>Number</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        @forelse (collect($stored_options)->sortBy('option') as $index => $option)
                            <tr class="text-center fw-bold">
                                {{-- <td>{{ $loop->index + 1 }}</td> --}}
                                <td>{{ $option['option'] }}</td>
                                <td>{{ $option['number'] }}</td>
                                <td>{{ $option['qty'] }}</td>
                                <td>{{ $option['total'] }}</td>
                                <td>
                                    <button class="btn btn-sm btn-danger" wire:click="deleteOption({{ $index }})"
                                        title="Delete">
                                        🗑
                                    </button>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center">No records found.</td>
                            </tr>
                        @endforelse
                    </tbody>

                    @php
                        $total = collect($stored_options)->sum('total');
                        $tq = $total > 0 ? floor($total / 11) : 0;

                        $drawCount = max(1, is_countable($selected_draw) ? count($selected_draw) : 1);

                        if (isset($selected_games) && is_countable($selected_games)) {
                            $gameCount = max(1, count($selected_games));
                        } elseif (!empty($selected_game_labels) && is_countable($selected_game_labels)) {
                            $gameCount = max(1, count($selected_game_labels));
                        } else {
                            $gameCount = 1;
                        }

                        $finalTotal = $total * $drawCount * $gameCount;
                    @endphp

                    <tfoot class="table-light position-sticky bottom-0" style="z-index: 2; background: #fff;">
                        <tr>
                            <td colspan="1" class="text-center">

                                <button class="btn btn-sm btn-danger" wire:click="clearAllOptionsIntoCache()">
                                    Clear All
                                </button>
                            </td>
                            <td colspan="6" class="fw-bold text-danger ">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span>
                                        TQ: {{ $tq }}
                                        Total: {{ $total }}
                                        FT (× {{ $drawCount }} draws ):
                                        {{ $finalTotal }}
                                    </span>
                                    <span>
                                        @error('draw_detail_simple')
                                            <div class="text-red-500">{{ $message }}</div>
                                        @enderror
                                        <span>

                                            <button class="btn btn-sm btn-primary" wire:click="submitTicket">
                                                Submit Ticket
                                            </button>

                            </td>

                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

</div>

{{-- Print + Shortcut Script --}}
@script
<script>
window.COMBINED_PRINTER = true;
window._printingRecently = false;
window._lastPrintArgs = null;

function _shouldProceedWithPrint(ticketNo, drawTime) {
    const key = `${ticketNo}::${drawTime}`;
    if (window._printingRecently && window._lastPrintArgs === key) return false;
    window._printingRecently = true;
    window._lastPrintArgs = key;
    setTimeout(() => {
        window._printingRecently = false;
        window._lastPrintArgs = null;
    }, 2000);
    return true;
}

function cleanPanelHtml(elem, title) {
    if (!elem) return '';
    const table = elem.querySelector ? elem.querySelector('table') : null;
    const wrapper = document.createElement('div');
    wrapper.className = 'panel-wrap';

    if (title) {
        const h = document.createElement('div');
        h.textContent = title;
        h.style.fontWeight = '700';
        h.style.marginBottom = '6px';
        wrapper.appendChild(h);
    }

    const target = table ? table.cloneNode(true) : elem.cloneNode(true);

    const interactive = target.querySelectorAll('button, input, textarea, select, .no-print, .btn, a');
    for (let i = 0; i < interactive.length; i++) interactive[i].remove();

    const attrElements = target.querySelectorAll('[wire\\:click],[wire\\:key],[wire\\:model]');
    for (let i = 0; i < attrElements.length; i++) {
        attrElements[i].removeAttribute('wire:click');
        attrElements[i].removeAttribute('wire:key');
        attrElements[i].removeAttribute('wire:model');
    }

    const theadRow = target.querySelector('thead tr');
    if (theadRow) {
        const ths = theadRow.querySelectorAll('th');
        let actionIdx = -1;
        for (let i = 0; i < ths.length; i++) {
            if ((ths[i].textContent || '').trim().toLowerCase().includes('action')) {
                actionIdx = i;
                break;
            }
        }
        if (actionIdx === -1 && ths.length > 0) actionIdx = ths.length - 1;
        if (actionIdx >= 0) {
            if (ths[actionIdx]) ths[actionIdx].remove();
            const bodyRows = target.querySelectorAll('tbody tr');
            for (let r = 0; r < bodyRows.length; r++) {
                const tds = bodyRows[r].querySelectorAll('td');
                if (tds.length > actionIdx) tds[actionIdx].remove();
            }
        }
    }

    const tfootBtns = target.querySelectorAll('tfoot button, tfoot .btn, tfoot input, tfoot select, tfoot textarea, tfoot a');
    for (let i = 0; i < tfootBtns.length; i++) tfootBtns[i].remove();

    wrapper.appendChild(target);
    return wrapper.outerHTML;
}

function extractVisibleTicketAndDraw() {
    const text = (document.body && document.body.innerText) ? document.body.innerText : '';
    let ticketNo = '';
    let drawText = '';
    let gameName = '';

    // Ticket No (same as before)
    const tn = text.match(/Ticket\s*No[:\s]*([A-Za-z0-9\-\_]+)/i);
    if (tn) ticketNo = tn[1].trim();

    // Find all "Draw: ..." occurrences (capture until pipe '|' or newline)
    const drawMatches = Array.from(text.matchAll(/Draw[:\s]*([^|\n\r]+)/gi));

    if (drawMatches.length) {
        // Clean and collect each draw entry (eg "05:45 pm , N2")
        const draws = drawMatches.map(m => {
            let s = (m[1] || '').trim();
            s = s.replace(/^\s*[,]+|[,]+\s*$/g, '').replace(/\s{2,}/g, ' ');
            return s;
        }).filter(Boolean);

        // drawText: join all draw entries with " | "
        drawText = draws.join(' | ');

            const games = draws.map(s => {
            const parts = s.split(/\s*,\s*/);
            if (parts.length >= 2) return parts.slice(1).join(', ').trim();
            const trailing = s.match(/\b([A-Za-z0-9]{1,30})$/);
            return trailing ? trailing[1] : '';
        }).filter(Boolean);

        // Unique game names joined by " | "
        if (games.length) {
            const uniq = Array.from(new Set(games));
            gameName = uniq.join(' | ');
        }
    } else {
        // Fallback: single-match behavior (keeps previous behavior)
        const d = text.match(/Draw[:\s]*([^\n\r]+)/i);
        if (d) {
            drawText = d[1].trim().replace(/\s{2,}/g, ' ').split(/\r?\n/)[0].trim();
        }
        const g = text.match(/Draw[:\s]*[^\|,]+[,|\|]\s*([^\|\n\r]+)/i);
        if (g) {
            gameName = g[1].trim().replace(/\s{2,}/g, ' ');
        }
    }

    return { ticketNo, drawText, gameName };
}


async function tryDirectPrinter(bytesToSend) {
    if (navigator.serial) {
        try {
            const ports = await navigator.serial.getPorts();
            let port = ports.length ? ports[0] : null;
            if (!port) port = await navigator.serial.requestPort();
            await port.open({ baudRate: 19200 });
            const writer = port.writable.getWriter();
            await writer.write(bytesToSend);
            writer.releaseLock();
            await port.close();
            return true;
        } catch (err) { /* fallthrough */ }
    }

    if (navigator.usb) {
        try {
            const devices = await navigator.usb.getDevices();
            let dev = devices.length ? devices[0] : null;
            if (!dev) dev = await navigator.usb.requestDevice({ filters: [] });
            await dev.open();
            if (dev.configuration === null) await dev.selectConfiguration(1);
            await dev.claimInterface(0);
            await dev.transferOut(1, bytesToSend);
            await dev.close();
            return true;
        } catch (err) { /* fallthrough */ }
    }

    return false;
}

function htmlToEscPosBytes(html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    const text = tmp.innerText || tmp.textContent || '';
    const encoder = new TextEncoder();
    const lines = text.split(/\r?\n/);
    const parts = [];
    for (let i = 0; i < lines.length; i++) parts.push(encoder.encode(lines[i] + '\n'));
    let total = 0;
    parts.forEach(p => total += p.length);
    const out = new Uint8Array(total);
    let offset = 0;
    parts.forEach(p => { out.set(p, offset); offset += p.length; });
    return out;
}

function formatPrintedAt(date) {
    const pad = (n) => String(n).padStart(2, '0');
    let dd = pad(date.getDate());
    let mm = pad(date.getMonth() + 1);
    let yyyy = date.getFullYear();

    let hours = date.getHours();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    if (hours === 0) hours = 12;
    let hh = pad(hours);

    let mins = pad(date.getMinutes());
    let secs = pad(date.getSeconds());

    return `${dd}-${mm}-${yyyy} ${hh}:${mins}:${secs} ${ampm}`;
}

function printStackedTicket() {
    setTimeout(async () => {
        const simpleElem = document.getElementById('printSimpleArea');
        const crossElem = document.getElementById('printCrossArea');
        const classAreas = simpleElem || crossElem ? null : Array.from(document.querySelectorAll('.print-area'));
        const simple = simpleElem || (classAreas && classAreas[0]) || null;
        const cross = crossElem || (classAreas && classAreas[1]) || (classAreas && classAreas[0]) || null;

        if (!simple && !cross) {
            alert('No ticket content found to print (Simple / Cross panels missing).');
            return;
        }

        const simpleHtml = simple ? cleanPanelHtml(simple, 'Simple ABC') : '';
        const crossHtml = cross ? cleanPanelHtml(cross, 'Cross ABC') : '';

        let ticketNo = {!! json_encode($selected_ticket->ticket_number ?? null) !!} || '';
        let drawTimeRaw = {!! json_encode($times ?? null) !!} || null;
        let gameName = {!! json_encode($labels ?? null) !!} || ''; 


        let drawTime = '';
        if (Array.isArray(drawTimeRaw)) drawTime = drawTimeRaw.join(', ');
        else if (typeof drawTimeRaw === 'string' && drawTimeRaw.length) drawTime = drawTimeRaw;

        if (!ticketNo || !drawTime || !gameName) {
            const visible = extractVisibleTicketAndDraw();
            if (!ticketNo && visible.ticketNo) ticketNo = visible.ticketNo;
            if (!drawTime && visible.drawText) drawTime = visible.drawText;
            if (!gameName && visible.gameName) gameName = visible.gameName;
        }

        ticketNo = ticketNo || '';
        drawTime = drawTime || '';
        gameName = gameName || '';

        const printedAt = formatPrintedAt(new Date());

        if (!_shouldProceedWithPrint(ticketNo, drawTime, gameName)) return;

        const styles = `
            <style>
              @page { size: auto; margin: 4mm; }
              html, body { height: auto; }
              body { font-family: monospace; font-size: 12px; margin: 0; padding: 4px; color:#000; font-weight: bold; }
              table { width: 100%; border-collapse: collapse; }
              th, td { padding: 4px 6px; border-bottom: 1px dotted #000; text-align: left; font-size:11px; font-weight: bold; }
              thead th { font-weight:700; }
              .section { margin-bottom: 6px; }
              .title { font-weight:bold; text-align:center; margin: 6px 0; }
              .panel-wrap { margin-bottom:6px; }
            </style>
        `;

        const html = `
            <html>
              <head><title>Print Ticket</title>${styles}</head>
              <body>
                <div class="title">Ticket No: ${ticketNo} | Draw: ${drawTime} | Game: ${gameName}</div>
                <div class="section">${simpleHtml}</div>
                <div class="section">${crossHtml}</div>
                <div class="printed-at">Printed At: ${printedAt}</div>
              </body>
            </html>
        `;

        try {
            const escBytes = htmlToEscPosBytes(html);
            const printed = await tryDirectPrinter(escBytes);
            if (printed) return;
        } catch (err) { /* continue to iframe fallback */ }

        try {
            const iframe = document.createElement('iframe');
            iframe.style.position = 'fixed';
            iframe.style.right = '0';
            iframe.style.bottom = '0';
            iframe.style.width = '380px';
            iframe.style.height = '1px';
            iframe.style.border = '0';
            iframe.style.overflow = 'hidden';
            iframe.setAttribute('aria-hidden', 'true');
            document.body.appendChild(iframe);

            const finalizeAndPrint = () => {
                try {
                    setTimeout(() => {
                        iframe.contentWindow.focus();
                        iframe.contentWindow.print();
                        setTimeout(() => iframe.remove(), 12000);
                    }, 120);
                } catch (err) {
                    const w = window.open('', '', 'width=380,height=600');
                    if (!w) {
                        alert('Popup blocked — allow popups to print.');
                        iframe.remove();
                        return;
                    }
                    w.document.open();
                    w.document.write(html);
                    w.document.close();
                    w.focus();
                    setTimeout(() => {
                        w.print();
                        w.close();
                    }, 2000);
                }
            };

            if ('srcdoc' in iframe) {
                iframe.srcdoc = html;
                iframe.onload = function() {
                    try {
                        const doc = iframe.contentDocument || iframe.contentWindow.document;
                        const body = doc.body;
                        setTimeout(() => {
                            const height = Math.max(body.scrollHeight, body.offsetHeight, doc.documentElement.scrollHeight);
                            iframe.style.height = (height + 10) + 'px';
                            finalizeAndPrint();
                        }, 60);
                    } catch (err) {
                        finalizeAndPrint();
                    }
                };
            } else {
                const idoc = iframe.contentWindow.document;
                idoc.open();
                idoc.write(html);
                idoc.close();
                iframe.onload = function() {
                    try {
                        const doc = iframe.contentDocument || iframe.contentWindow.document;
                        const body = doc.body;
                        setTimeout(() => {
                            const height = Math.max(body.scrollHeight, body.offsetHeight, doc.documentElement.scrollHeight);
                            iframe.style.height = (height + 10) + 'px';
                            finalizeAndPrint();
                        }, 60);
                    } catch (err) {
                        finalizeAndPrint();
                    }
                };
            }
        } catch (e) {
            const w = window.open('', '', 'width=380,height=600');
            if (!w) {
                alert('Popup blocked — allow popups to print.');
                return;
            }
            w.document.open();
            w.document.write(html);
            w.document.close();
            w.focus();
            setTimeout(() => {
                w.print();
                w.close();
            }, 2000);
        }
    }, 120);
}

if (window.Livewire && Livewire.on) {
    Livewire.on('ticketSubmitted', () => {
        printStackedTicket();
    });
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'F12') printStackedTicket();
});
</script>
@endscript
