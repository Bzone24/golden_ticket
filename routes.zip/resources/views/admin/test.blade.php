@extends('admin.layouts.base')
@section('title', 'Test Title')
@section('contents')
    <div class="container-fluid">
        <h2 class="text-center">Test</h2>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        Test Header
                    </div>
                    <div class="card-body">
                        This is card body
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
