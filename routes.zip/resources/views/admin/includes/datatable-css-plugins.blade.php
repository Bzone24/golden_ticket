{{-- <link rel="stylesheet" href="{{ asset('assets/datatable/css/dataTables.dataTables.css') }}" />
<link href="{{ asset('assets/datatable/css/bootstrap.min.css') }}" rel="stylesheet">

<link rel="stylesheet" href="{{ asset('assets/datatable/css/select.bootstrap5.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/datatable/css/buttons.dataTables.min.css') }}"> --}}
{{-- <link rel="stylesheet" href="https://cdn.datatables.net/2.3.2/css/dataTables.dataTables.min.css" /> --}}

{{-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css">

<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap5.min.css"> --}}
