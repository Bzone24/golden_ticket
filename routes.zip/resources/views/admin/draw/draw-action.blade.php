<div class="text-end">
    <div class="d-flex justify-content-center">
        <a href="{{ route('admin.add.draw', ['draw_id' => $draw->id]) }}" class="btn btn-warning ms-3 text-white"><i
                class="fa fa-pencil"></i> Edit</a>
    </div>
</div>
