@extends('web.layouts.base')
@section('title','GameTicketHub')
@section('contents')
@include('web.includes.metro-section')
  <!-- Features Section -->
 @include('web.includes.feature-section')
  <!-- Footer -->
 @include('web.includes.footer')
@endsection