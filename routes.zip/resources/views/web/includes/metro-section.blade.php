 <section class="hero">
    <div class="container">
      <h1>Book Your Game Tickets Instantly!</h1>
      <p class="lead my-4">Explore thrilling matches and tournaments. Grab your seat before it’s gone!</p>
      <a href="#" class="btn btn-primary btn-lg">Browse Games</a>
    </div>
  </section>