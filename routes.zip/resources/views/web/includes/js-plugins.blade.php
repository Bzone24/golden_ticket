   <script src="{{ asset('assets/js/common/jquery-min.js') }}"></script>
   <script src="{{ asset('assets/js/common/bootstrap.bundle.min.js') }}"></script>
   <script src="{{ asset('assets/js/common/moment.min.js') }}"></script>
   <script src="{{ asset('assets/js/common/daterangepicker.min.js') }}"></script>
   <script src="{{ asset('assets/js/common/daterange-filter.js') }}"></script>


   {{-- <script src="{{ asset('assets/js/common/sweet-alert.js') }}"></script> --}}
