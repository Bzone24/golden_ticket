<link href="{{ asset('assets/css/common/bootstrap.min.css') }}" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('assets/web/css/custom-style.css') }}" />

{{-- <link href="{{ asset('assets/css/common/all.min.css') }}" rel="stylesheet"> --}}
<link rel="stylesheet" href="{{ asset('assets/web/css/style.css') }}" />
<link href="{{ asset('assets/css/common/common-style.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/common/daterangepicker.css') }}" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
