<div class="card mb-3 h-100">

    <!-- Timer Header -->
    @include('livewire.ticket-data-form')

    <div class="card-header text-black">
        <div class="d-flex justify-content-between align-items-center px-2 py-1 border-bottom w-100">
            @php
                use Illuminate\Support\Str;
                use Illuminate\Support\Carbon;

                // Helper: detect whether a time string contains seconds
                $formatFromString = function ($s) {
                    return is_string($s) && substr_count($s, ':') >= 2 ? 'g:i:s A' : 'g:i A';
                };

                $addOneMinute = function ($t) use ($formatFromString) {
                    try {
                        $dt = Carbon::parse($t)->addMinute();
                        $fmt = $formatFromString((string) $t);
                        return $dt->format($fmt);
                    } catch (\Throwable $e) {
                        return $t;
                    }
                };

                if (!empty($selected_times)) {
                    $selected_times_arr = is_array($selected_times) ? $selected_times : [$selected_times];
                    $times = array_map($addOneMinute, $selected_times_arr);
                } elseif (isset($active_draw)) {
                    $raw = $active_draw->formatEndTime();
                    $times = [$addOneMinute($raw)];
                } else {
                    $times = [];
                }

                // Build labels (preserve original intent)
                $labels = !empty($selected_game_labels)
                    ? $selected_game_labels
                    : collect($games ?? [])
                        ->whereIn('id', $selected_games ?? [])
                        ->map(fn($g) => strtoupper($g->code ?? ($g->short_code ?? ($g->name ?? ''))))
                        ->values()
                        ->all();
            @endphp

            <h6 class="mb-0 w-100 text-center" id="printHeaderTitle">
                @foreach ($this->selectedDraws as $key => $draw)
                    <strong>Draw:</strong> {{ $draw->formatResultTime() }} ,
                    {{ $draw->draw->game->name }} |
                @endforeach
            </h6>
        </div>
    </div>

    <div class="card-body pb-0 py-0">
        {{-- Simple ABC Section --}}
        <div class="mb-0">
            <h5 class="fw-semibold">Simple ABC</h5>

            <!-- Fixed height + scroll only inside table area -->
            <div id="printSimpleArea" style="max-height: 300px; overflow-y: auto;">
                <table class="table table-bordered table-striped table-hover mb-0 text-center fw-bold">
                    <thead class="table-light position-sticky top-0" style="z-index: 1;">
                        <tr>
                            <th>#</th>
                            <th>Option</th>
                            <th>Number</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        @forelse (collect($stored_options)->sortBy('option') as $index => $option)
                            <tr class="text-center fw-bold">
                                <td>{{ $loop->index + 1 }}</td>
                                <td>{{ $option['option'] }}</td>
                                <td>{{ $option['number'] }}</td>
                                <td>{{ $option['qty'] }}</td>
                                <td>{{ $option['total'] }}</td>
                                <td>
                                    <button class="btn btn-sm btn-danger" wire:click="deleteOption({{ $index }})"
                                        title="Delete">🗑</button>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center">No records found.</td>
                            </tr>
                        @endforelse
                    </tbody>

                    @php
                        // totals (kept exact same calculations & constants)
                        $total = collect($stored_options)->sum('total');
                        $tq = $total > 0 ? floor($total / 11) : 0;

                        $drawCount = max(1, is_countable($selected_draw) ? count($selected_draw) : 1);

                        if (isset($selected_games) && is_countable($selected_games)) {
                            $gameCount = max(1, count($selected_games));
                        } elseif (!empty($selected_game_labels) && is_countable($selected_game_labels)) {
                            $gameCount = max(1, count($selected_game_labels));
                        } else {
                            $gameCount = 1;
                        }

                        $finalTotal = $total * $drawCount * $gameCount;
                    @endphp

                    <tfoot class="table-light position-sticky bottom-0" style="z-index: 2; background: #fff;">
                        <tr>
                            <td colspan="1" class="text-center">
                                <button class="btn btn-sm btn-danger" wire:click="clearAllOptionsIntoCache()">
                                    Clear All
                                </button>
                            </td>
                            <td colspan="6" class="text-end">
                                @error('draw_detail_simple')
                                    <div class="text-red-500">{{ $message }}</div>
                                @enderror
                                <button class="btn btn-sm btn-primary" wire:click="submitTicket">
                                    Submit Ticket
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="7" class="fw-bold text-danger text-start totals-row">
                                TQ: {{ $tq }}
                                &nbsp; | &nbsp; Total: {{ $total }}
                                &nbsp; | &nbsp; FT (× {{ $drawCount }} draws ): {{ $finalTotal }}
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

</div>

{{-- Print + Shortcut Script --}}
@script
<script>
document.addEventListener('ticket-submitted', function(e) {
    try {
        // payload may arrive as e.detail or e.detail.payload
        const rawDetail = (e && e.detail && e.detail.payload) ? e.detail.payload : (e && e.detail ? e.detail : {});

        const ticketNo = rawDetail.ticket_number || '';
        const drawsArr = Array.isArray(rawDetail.draws) ? rawDetail.draws : [];

        // Build draws string preserving compatibility with old payload shapes
        let drawsStr = '';
        if (drawsArr.length) {
            drawsStr = drawsArr.map(d => {
                const time = d.time || d.t || '';
                const game = d.game || d.g || '';
                return (time ? time : '') + (game ? (time ? ' , ' : '') + '(' + game + ')' : '');
            }).join(' | ');
        } else if (Array.isArray(rawDetail.times) && rawDetail.times.length) {
            drawsStr = rawDetail.times.join(' | ');
        } else if (Array.isArray(rawDetail.labels) && rawDetail.labels.length) {
            drawsStr = rawDetail.labels.join(' | ');
        }

        const header = `
            <div style="text-align:center; margin-bottom:6px;">
                <strong>Ticket No:</strong> ${ticketNo || ''}<br>
                <strong>Draw:</strong> ${drawsStr}
            </div>
            <hr>
        `;

        function cleanClone(areaId, sectionTitle) {
            const orig = document.getElementById(areaId);
            if (!orig) return '';

            const clone = orig.cloneNode(true);

            // Remove UI controls (buttons)
            clone.querySelectorAll('button, .btn, [type="button"]').forEach(x => x.remove());

            // Remove "Action" column by header detection (keeps totals rows intact)
            const table = clone.querySelector('table');
            if (table) {
                const ths = Array.from(table.querySelectorAll('th'));
                let actionIndex = -1;
                ths.forEach((th, i) => {
                    if ((th.innerText || '').toLowerCase().includes('action')) {
                        actionIndex = i;
                        th.remove();
                    }
                });
                if (actionIndex > -1) {
                    Array.from(table.querySelectorAll('tr')).forEach(tr => {
                        if (tr.classList.contains('totals-row')) return;
                        if (tr.cells[actionIndex]) tr.deleteCell(actionIndex);
                    });
                }
            }

            return `<h4 style="margin:6px 0 4px 0; font-weight:bold;">${sectionTitle}</h4>` + clone.innerHTML;
        }

        const simpleHTML = cleanClone('printSimpleArea', 'Simple ABC');
        const crossHTML  = cleanClone('printCrossArea',  'Cross ABC'); // if not present, cleanClone returns ''
        const content = header + simpleHTML + crossHTML;

        const win = window.open('', '', 'width=320,height=600');
        win.document.write(`
            <html>
            <head>
                <title>Print Ticket</title>
                <style>
    body { 
        font-family: Arial, sans-serif; 
        font-size: 16px;       /* bigger font */
        font-weight: bold;     /* all bold */
        margin: 0; 
        padding: 6px; 
    }
    table { 
        width: 100%; 
        border-collapse: collapse; 
    }
    th, td { 
        padding: 6px 8px;      /* more spacing */
        text-align: left; 
        border-bottom: 2px solid #000; /* thicker border */
    }
    tfoot td, .totals-row { 
        font-weight: bold; 
        border-top: 2px solid #000; 
        font-size: 18px;       /* even bigger for totals */
    }
    h4 { 
        font-size: 18px; 
        margin: 8px 0 6px 0; 
    }
    hr { 
        border: none; 
        border-top: 2px dashed #000; 
        margin: 6px 0; 
    }
</style>

            </head>
            <body>${content}</body>
            </html>
        `);
        win.document.close();

        // small delay to allow rendering; then print and close
        setTimeout(() => { try { win.print(); } catch (ignore) {} try { win.close(); } catch (ignore) {} }, 300);
    } catch (err) {
        
    }
});


</script>
@endscript
